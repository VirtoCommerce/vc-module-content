﻿angular.module('virtoCommerce.contentModule')
.controller('virtoCommerce.contentModule.blogsWidgetController', ['$scope', 'platformWebApp.bladeNavigationService', function ($scope, bladeNavigationService) {
	var blade = $scope.widget.blade;
    
}]);