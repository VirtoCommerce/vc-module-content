﻿angular.module('virtoCommerce.contentModule')
.controller('virtoCommerce.contentModule.themeActiveWidgetController', ['$state', '$scope', 'platformWebApp.bladeNavigationService', function ($state, $scope, bladeNavigationService) {
    var blade = $scope.widget.blade;

    //$scope.openBlade = function () {
    //	$state.go('workspace.content', { storeId: blade.currentEntity.id});
    //};

}]);
